﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Week_3_Assignment
{
    internal class Program
    {
        static void Main(string[] args)
        {
            ArrayList course = new ArrayList();
            course.Add(new GUFormatter());
            course.Add(new GUFormatter());
            course.Add(new GUFormatter());
            foreach( GUFormatter student in course)
            {
                Console.WriteLine(student.printReport());
                Console.WriteLine("Press Enter For Next Student: ");
                Console.ReadLine();
            }
            Console.ReadLine();
        }
    }
}
