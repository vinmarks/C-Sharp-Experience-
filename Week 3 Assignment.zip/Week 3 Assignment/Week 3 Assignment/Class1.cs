﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Week_3_Assignment
{
    internal class GradesUtil
    {//add arrarylist somehow
        private ArrayList grades; //= new ArrayList();
        private float total;
        private float average;
        protected char letter;
        private string name;
        
      
        public GradesUtil()
        { 
            this.grades = new ArrayList();
            Console.Write("Enter the grades earned (-1 to stop)\n:>");
            float grade = float.Parse(Console.ReadLine().ToString());
            while (grade != -1.0f)
            {
                this.grades.Add(grade);
                Console.Write(":>");
                grade = float.Parse(Console.ReadLine());
            }

            // CALCULATE total
            float sum = 0.0f;
            foreach(float g in this.grades)
            {
                sum += g;
            }
            //set total
            this.total = sum;
            //caluclate and set average
            this.average = this.total / this.grades.Count;

            switch (this.average)
            {
                case float n when(n >= 90):
                    this.letter = 'A'; break;
                case float n when (n >= 80):
                    this.letter = 'B'; break;
                case float n when (n >= 70):
                    this.letter = 'C'; break;
                case float n when (n >= 60):
                    this.letter = 'D'; break;
                case float n when (n < 60):
                    this.letter = 'F'; break;
                default:
                    break;

            }
            Console.WriteLine("Student Entry Successful");
        }



        public int getCount()
        {
            return this.grades.Count;


        }
        public float getTotal()
        {
            return this.total;

        }
        public float getAverage()
        {
            return this.average;
        }
        public char getLetter()
        {
            return this.letter; 
        }

    }
}
