﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Week_3_Assignment
{
    //Superclass = gradesUtil
    // subclass = GUIFormater
    internal class GUFormatter : GradesUtil
    {
        public GUFormatter() : base()
        {
            
        }

        public string printReport()
        {
            return "======================="
                + "\nAverage:" + this.getAverage().ToString()
                + "\nLetter Grade:" + this.getLetter().ToString()
                + "\nTotal Points:" + this.getTotal().ToString()
                + "\nNumber of Grades Calulated:" + getCount().ToString()
                + "\n========================";
            

            // access attributes to parent class
            // get accessors
            // access directly for it to work
        }
    }


}
