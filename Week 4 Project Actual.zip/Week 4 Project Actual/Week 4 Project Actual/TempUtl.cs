﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Xml;

namespace Week_4_Project_Actual
{
    internal class TempUtl
    {
        
        private string[] daysOfWeek = {"Mon", "Tue", "Wed", "Thur",
                                "Fri", "Sat", "Sun"};
        // a single comma ([,]) denotes 2-dimensions
        private float[,] temps = { { 45.7f, 40.2f},
                           { 47.8f, 31.5f },
                           {30.2f, 35.5f },
                           {32.3f, 38.6f },
                           {40.4f, 40.5f },
                           {43.6f, 43.2f },
                           {52.0f, 47.1f } };
        
        public char mode = 'f';

        public bool dispUnits = false;



        public TempUtl()
        {
            Console.WriteLine("Enter Desired Unit of Temperature Measurement (f or c): ");
            // value within the square bracket specifies which character is of interest
            // [0] calls for the first character entered. 
            // user could enter 'Fahrenheit' and get the same result.
            // had char-string conversion errors prior to implementing [0] 
            char unitChoice = Console.ReadLine()[0];

            if (unitChoice == 'f')
            {
                string output = " ";
                // Header
                output += "Day\t Morning Temp Evening Temp\n";

                //Counter. As long as Day is less than the Length of a Week
                // increase the count by one (until you reach 6(which is actually 7))
                for (int day = 0; day < daysOfWeek.GetLength(0); day++)
                {
                    // "appends" each string iteration to the created "output" string variable.
                    output +=  daysOfWeek[day]
                            // iterates each day of the week combined with associated 
                            // morning and evening temps.
                            // day,0/day,1 translates to: day of week[0=morning][1=evening]
                            // concantinated with f for fahrenhiet
                            // simple but effective
                            // proper formatting (from left/from right) would be beneficial
                            // failed to implement such formatting correctly.
                            + "\t\t" + temps[day, 0] + 'f'
                            +  "\t     " + temps[day, 1] + 'f'
                            + "\n";
                     
                }
                Console.WriteLine(output);
                Console.ReadLine();

            }
            else
            {
                string output2 = " ";
                output2 += "Day\t Morning Temp Evening Temp\n\n";
                for (int day = 0;day < daysOfWeek.GetLength(0); day++)
                {
                    // conversion to celsius
                    // extracting morning and evening temps by indexing them 
                    // via iteration. 
                    // inserting each individual temp to a F -> C conversion
                    float farTemp1 = temps[day, 0];
                    float farTemp2 = temps[day, 1];
                    double celTemp1 = (farTemp1 - 32) * .5556;
                    double celTemp2 = (farTemp2 - 32) * .5556;
                    
                    // Repeating the output string from above. 
                    // Using the newly found value of Celsius and rounding it
                    // to a max of two decimals.
                    // concantinating with "c" to denote celsius
                    output2 += daysOfWeek[day]
                            + "\t\t" + Math.Round(celTemp1, 2) + "c"
                            + "\t     " + Math.Round(celTemp2, 2) + "c"
                            + "\n";
                    
                }
                Console.WriteLine(output2);
                Console.ReadLine();
            }


        }
        // getters and setters
        public void setMode(char newMode)
        {
            this.mode = newMode;
        }

        public char getMode()
        {
            return this.mode;
        }

        public bool setDispUnits(bool newDispUnits)
        {
           return this.dispUnits = newDispUnits;
            
        }

       
        
    }   
}
