﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Week_4_Project_Actual
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to Your Weekly Forecast\n========================");
            Console.WriteLine("\nPress Enter to Continue");
            Console.ReadLine();   
            new TempUtl();
        }   

    }
}
