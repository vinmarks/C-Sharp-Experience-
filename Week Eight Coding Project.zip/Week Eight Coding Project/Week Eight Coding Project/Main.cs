﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TextBox;

namespace Week_Eight_Coding_Project
{
    public partial class Main : Form
    {
        // Globals
        public ArrayList accounts = new ArrayList();
        private string fileName;

        private StreamWriter filewriter;
        private StreamReader fileReader;

        private bool accountChanged = false;
        public bool archive = false;

        public Main()
        {
            InitializeComponent();
        }

        
        // Welcome Message
        private void Main_Load(object sender, EventArgs e)
        {
            MessageBox.Show("Welcome!\n\nPlease Select or Create a Data File\n\nthrough the File Menu located\n\nat the Top of the Window!");
                                          
        }

        // File Menu Strip 
        private void newAccountToolStripMenuItem_Click(object sender, EventArgs e)
        {
            NewAccount frmNew = new NewAccount();
            frmNew.ShowDialog(this);
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {   // generates message box that asks user if they would like to save
                // prompt is message inside dialog box
                // messageBox is the window name
                String prompt = "Would You Like to Save Changes Before Leaving?";
                String messageBox = "Save File";
                MessageBoxButtons buttons = MessageBoxButtons.YesNo;
                MessageBoxIcon ico = MessageBoxIcon.Question;
                DialogResult result;
                result = MessageBox.Show(this, prompt, messageBox, buttons, ico);
                if (result == DialogResult.Yes)
                {
                    var output = new FileStream(fileName, FileMode.Open, FileAccess.Write);
                    filewriter = new StreamWriter(output);

                    foreach (BankAccount ba in accounts)
                    {  // writes the BankAccount attributes to the file
                        filewriter.WriteLine($"{ba.accountNo},{ba.lastName},{ba.balance.ToString()}");
                    }
                    MessageBox.Show("Saved Successful!", "Saved",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Close();

                }
                else
                {
                    this.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Saving Failed:" + ex.Message.ToString(), "Save",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void selectDataFileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Captures user input
            DialogResult result;
            // Checks to see if file is valid, and loads file when user clicks ok
            using (var fileChooser = new OpenFileDialog())
            {
                fileChooser.CheckFileExists = true; 
                result = fileChooser.ShowDialog();
                if (result == DialogResult.OK)
                {
                    fileName = fileChooser.FileName;

                }
            }
            if (result == DialogResult.OK)
            {
                if (string.IsNullOrEmpty(fileName))
                {
                    MessageBox.Show("Invalid File Name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                else
                {
                    try
                    {
                        var input = new FileStream(fileName, FileMode.Open, FileAccess.Read);
                        // reads data
                        fileReader = new StreamReader(input);
                        // will continue to read data until empty line
                        var line = fileReader.ReadLine();
                        while (line != null)
                        {   // splits values based on location of comma within the line of data
                            string[] values = line.Split(',');
                            // creating new array based on values from data file.
                            //indexing organizes the object by second value first, then first value, then third value
                            accounts.Add(new BankAccount(values[1], values[0], float.Parse(values[2])));
                            line = fileReader.ReadLine();
                        }
                        input.Close();
                    }
                    catch (IOException ex)
                    {
                        MessageBox.Show($"Error Opening File: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }

                foreach (BankAccount ba in accounts)
                {
                    // adding accountNo from BankAccount constructor for display
                    // within the combo box
                    cmbAccountNo.Items.Add(ba.accountNo);
                }
                // detects interaction with combo box
                // hands it off to the event listener
                cmbAccountNo.SelectedValueChanged += new System.EventHandler(this.cmbAccountNo_SelectedValueChanged);

                MessageBox.Show("File Found!\nAccess Accounts Via the 'Account No: ' Drop Down Box.\n\n Select File -> New Account to Add an Account");
            }
        }

        private void newDataFileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Stream myStream;
            SaveFileDialog saveFileDialog1 = new SaveFileDialog();
            
            saveFileDialog1.Filter = "txt files (*.txt)|*.txt";
            saveFileDialog1.FilterIndex = 2;
            saveFileDialog1.RestoreDirectory = true;


            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                if ((myStream = saveFileDialog1.OpenFile()) != null)
                {
                    
                    cmbAccountNo.Items.Clear();
                    accounts.Clear();
                    txtBalance.Clear();
                    txtLName.Clear();
                    
                    
                }
                    

            }
        }
        private void displayAccountsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Report rp = new Report();
            rp.ShowDialog(this);
        }

        // Run Report
        public string getRecordsString()
        {   //*********maybe use a string builder
            string data = "";
            foreach (BankAccount ba in accounts)
            {
                data += ba.getData();
            }
            return data;
        }


        // Elements
        private void cmbAccountNo_SelectedValueChanged(object sender, EventArgs e)
        {
            //accountChanged = true;
            foreach (BankAccount ba in accounts)
            {   //if Bank Account Number is within the combo box
                //  last name and balance attributes are gathered and assigned accordingly
                if (ba.accountNo == cmbAccountNo.SelectedItem.ToString())
                {
                    txtLName.Text = ba.lastName;
                    txtBalance.Text = ba.balance.ToString();
                }
            }
        }   //accountChanged = false;

        private void openFileDialog1_FileOk(object sender, System.ComponentModel.CancelEventArgs e)
        {
            // handles the event upon clicking ok in file open dialog box
            this.Activate();
            string[] files = openDataFile.FileNames;

            foreach (string file in files)
            {
                System.IO.FileInfo fileInfo = new System.IO.FileInfo(file);
                System.IO.FileStream fileStream = fileInfo.OpenRead();

            }

        
        }

        private void txtLName_TextChanged(object sender, EventArgs e)
        {
            
            // enables update file button and updates array list values based on
            // selected account number within the combo box
            this.archive = true;
            this.btnUpdateFile.Enabled = true;
            foreach (BankAccount ba in accounts)
            {
                if (ba.accountNo == (string)cmbAccountNo.SelectedItem.ToString())
                    ba.lastName = txtLName.Text;
            }
            
        }

        private void txtBalance_TextChanged(object sender, EventArgs e)
        {
            
            // enables update file button and updates array list values based on
            // selected account number within the combo box
            this.archive = true;
            this.btnUpdateFile.Enabled = true;
            foreach (BankAccount ba in accounts)
            {
                if(ba.accountNo == (string) cmbAccountNo.SelectedItem.ToString())
                    ba.balance = float.Parse(txtBalance.Text);
            }
            
        }

        private void btnUpdateFile_Click(object sender, EventArgs e)
        {   //error message for attempt to save to invalid file name 
            if (string.IsNullOrEmpty(fileName))
            {
                MessageBox.Show("Invalid FIle Name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                selectDataFileToolStripMenuItem_Click(sender, e);
            }
            
            try
            {    //finds, opens, and writes to selected file
                 var output = new FileStream(fileName, FileMode.Open, FileAccess.Write);
                 filewriter = new StreamWriter(output);

                 foreach (BankAccount ba in accounts)
                 {  // writes the BankAccount attributes to the file
                    filewriter.WriteLine($"{ba.accountNo},{ba.lastName},{ba.balance.ToString()}");
                 }
                 filewriter.Close();
                 output.Close();
                MessageBox.Show("Account Was Updated!");
            }
            catch (IOException er)
            {
                MessageBox.Show(er.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            
        }

       
    }


}
