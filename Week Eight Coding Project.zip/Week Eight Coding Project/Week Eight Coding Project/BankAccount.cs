﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Week_Eight_Coding_Project
{
    internal class BankAccount
    {
        public string accountNo;
        public string lastName;
        public float balance;
        public BankAccount(string name, string account, float balance)
        {
            try
            {
                lastName = name;
                accountNo = account;
                this.balance = balance;
            }
            catch
            {
                MessageBox.Show("Error creating account, check data format", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    
        public string getData()
        {
            string data = "";
            if (this.accountNo != null)
            {   // Substring() implemented to protect account number information 
                data = $"Account:\n***{this.accountNo.Substring(3)}\nName: {this.lastName}\nBalance: ${this.balance}\n\n";
                
            }
            else
            {
                data = $"Account: [unknown]\nName: {this.lastName}\nBalance: ${this.balance.ToString()}";
                
            }
            return data;
        }


        
    }
}
