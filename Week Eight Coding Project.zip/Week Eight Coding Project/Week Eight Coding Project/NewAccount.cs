﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Week_Eight_Coding_Project
{
    
    public partial class NewAccount : Form
    {
        public NewAccount()
        {
            InitializeComponent();
        }
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close(); 
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            string lname = txtNewLName.Text;
            string account = txtNewAccountNo.Text;
            float balance = float.Parse(txtBalance.Text.ToString());

            // creates new object and adds it to the accounts list
            // it then clears the combo box before repopulating it
            Main parent = (Main)this.Owner; 
            parent.accounts.Add(new BankAccount(lname, account, balance));
            parent.cmbAccountNo.Items.Clear();
            foreach (BankAccount ba in parent.accounts)
            {
                parent.cmbAccountNo.Items.Add(ba.accountNo);
            }
            MessageBox.Show("New Account Created\n\nWarning:\n- Select Account Numbert\n- Verify Information\n- Click Update File to Save Changes");
            this.Close();
        }
        
       
    }
}
