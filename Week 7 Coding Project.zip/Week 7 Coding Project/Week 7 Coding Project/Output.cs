﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Week_7_Coding_Project
{
    public partial class Output : Form
    {
        Main frmM;
        public Output(Main frmMain)
        {
            // connecting to Main class
            // assigning frmM to frmMain is crucial to this process
            InitializeComponent();
            frmM = frmMain;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Output_Load(object sender, EventArgs e)
        {
            // Calling the getFormattedstring method from the Main class..
            // .. which supplies the data.
            txtOutput.Text = frmM.getFormattedString();


        }
    }
}
