﻿namespace Week_7_Coding_Project
{
    partial class Main
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            txtFName = new TextBox();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            txtLName = new TextBox();
            txtOutput = new TextBox();
            chkReversed = new CheckBox();
            showName = new Button();
            menuStrip3 = new MenuStrip();
            fileToolStripMenuItem = new ToolStripMenuItem();
            clearFormToolStripMenuItem = new ToolStripMenuItem();
            outputToMessageBoxToolStripMenuItem = new ToolStripMenuItem();
            outputToWindowToolStripMenuItem = new ToolStripMenuItem();
            menuStrip3.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(82, 53);
            label1.Name = "label1";
            label1.Size = new Size(87, 20);
            label1.TabIndex = 0;
            label1.Text = "First Name: ";
            // 
            // txtFName
            // 
            txtFName.BorderStyle = BorderStyle.FixedSingle;
            txtFName.Location = new Point(174, 51);
            txtFName.Name = "txtFName";
            txtFName.Size = new Size(125, 27);
            txtFName.TabIndex = 1;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(82, 95);
            label2.Name = "label2";
            label2.Size = new Size(86, 20);
            label2.TabIndex = 2;
            label2.Text = "Last Name: ";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(59, 134);
            label3.Name = "label3";
            label3.Size = new Size(109, 20);
            label3.TabIndex = 3;
            label3.Text = "Reverse Order: ";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(106, 191);
            label4.Name = "label4";
            label4.Size = new Size(62, 20);
            label4.TabIndex = 4;
            label4.Text = "Output: ";
            // 
            // txtLName
            // 
            txtLName.BorderStyle = BorderStyle.FixedSingle;
            txtLName.Location = new Point(174, 93);
            txtLName.Name = "txtLName";
            txtLName.Size = new Size(125, 27);
            txtLName.TabIndex = 5;
            // 
            // txtOutput
            // 
            txtOutput.BorderStyle = BorderStyle.FixedSingle;
            txtOutput.Location = new Point(174, 189);
            txtOutput.Name = "txtOutput";
            txtOutput.ReadOnly = true;
            txtOutput.Size = new Size(125, 27);
            txtOutput.TabIndex = 6;
            // 
            // chkReversed
            // 
            chkReversed.AutoSize = true;
            chkReversed.Location = new Point(174, 137);
            chkReversed.Name = "chkReversed";
            chkReversed.Size = new Size(18, 17);
            chkReversed.TabIndex = 7;
            chkReversed.UseVisualStyleBackColor = true;
            // 
            // showName
            // 
            showName.Location = new Point(118, 252);
            showName.Name = "showName";
            showName.Size = new Size(155, 29);
            showName.TabIndex = 8;
            showName.Text = "Display Name";
            showName.UseVisualStyleBackColor = true;
            showName.Click += showName_Click;
            // 
            // menuStrip3
            // 
            menuStrip3.ImageScalingSize = new Size(20, 20);
            menuStrip3.Items.AddRange(new ToolStripItem[] { fileToolStripMenuItem });
            menuStrip3.Location = new Point(0, 0);
            menuStrip3.Name = "menuStrip3";
            menuStrip3.Size = new Size(800, 28);
            menuStrip3.TabIndex = 11;
            menuStrip3.Text = "menuStrip3";
            // 
            // fileToolStripMenuItem
            // 
            fileToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { clearFormToolStripMenuItem, outputToMessageBoxToolStripMenuItem, outputToWindowToolStripMenuItem });
            fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            fileToolStripMenuItem.Size = new Size(46, 24);
            fileToolStripMenuItem.Text = "File";
            // 
            // clearFormToolStripMenuItem
            // 
            clearFormToolStripMenuItem.Name = "clearFormToolStripMenuItem";
            clearFormToolStripMenuItem.Size = new Size(247, 26);
            clearFormToolStripMenuItem.Text = "Clear Form";
            clearFormToolStripMenuItem.Click += clearFormToolStripMenuItem_Click;
            // 
            // outputToMessageBoxToolStripMenuItem
            // 
            outputToMessageBoxToolStripMenuItem.Name = "outputToMessageBoxToolStripMenuItem";
            outputToMessageBoxToolStripMenuItem.Size = new Size(247, 26);
            outputToMessageBoxToolStripMenuItem.Text = "Output to Message Box";
            outputToMessageBoxToolStripMenuItem.Click += outputToMessageBoxToolStripMenuItem_Click;
            // 
            // outputToWindowToolStripMenuItem
            // 
            outputToWindowToolStripMenuItem.Name = "outputToWindowToolStripMenuItem";
            outputToWindowToolStripMenuItem.Size = new Size(247, 26);
            outputToWindowToolStripMenuItem.Text = "Output to Window";
            outputToWindowToolStripMenuItem.Click += outputToWindowToolStripMenuItem_Click;
            // 
            // Main
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(showName);
            Controls.Add(chkReversed);
            Controls.Add(txtOutput);
            Controls.Add(txtLName);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(txtFName);
            Controls.Add(label1);
            Controls.Add(menuStrip3);
            Name = "Main";
            Text = "Main";
            menuStrip3.ResumeLayout(false);
            menuStrip3.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox txtFName;
        private Label label2;
        private Label label3;
        private Label label4;
        private TextBox txtLName;
        private TextBox txtOutput;
        private CheckBox chkReversed;
        private Button showName;
        private MenuStrip menuStrip3;
        private ToolStripMenuItem fileToolStripMenuItem;
        private ToolStripMenuItem clearFormToolStripMenuItem;
        private ToolStripMenuItem outputToMessageBoxToolStripMenuItem;
        private ToolStripMenuItem outputToWindowToolStripMenuItem;
    }
}