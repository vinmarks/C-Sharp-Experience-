using System.Xml.Linq;

namespace Week_7_Coding_Project
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }

        private void showName_Click(object sender, EventArgs e)
        {
            txtOutput.Text = getFormattedString();
        }

        public string getFormattedString()
        {
            // assigns txtFname and txtLname to the data variable and the returns it
            // if/else statements determine order of names dependent upon check box
            // this method can be used repeatedly
            string data = " ";
            string fname = txtFName.Text;
            string lname = txtLName.Text;
            if (chkReversed.Checked)
            {
                data = lname + ", " + fname;
            }
            else
                data = fname + " " + lname;

            return data;
        }

        private void clearFormToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // clears all values
            // returns check box to unchecked
            txtFName.Clear();
            txtLName.Clear();
            txtOutput.Clear();
            chkReversed.Checked = false;
        }

        private void outputToMessageBoxToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // passes the data from the getFormattedString method to the message box
            // pairs this information with a message
            // the OK button is pre-programmed
            MessageBox.Show(getFormattedString(), "Your Name is: ", MessageBoxButtons.OK);
        }

        private void outputToWindowToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Passing itself in order to connect to the Output Class/Form
            Output frmOutput = new Output(this);
            // displays the second form (Output Window)
            frmOutput.ShowDialog();

        }
    }
}